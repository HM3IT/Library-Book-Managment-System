package infoSystem;

public enum BookProperty{
	  ISBN,
	  TITLE,
	  CATEGORY,
	  AUTHOR,
	  EDITION,
	  PUBLISHER,
}